package com.niit.bookback.dao.impl;

import java.util.List;

import com.niit.bookback.dao.CategoryDAO;
import com.niit.bookback.model.Category;

public class CategoryDAOImpl implements CategoryDAO {

	public boolean save(Category category) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean update(Category category) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean delete(Category category) {
		// TODO Auto-generated method stub
		return false;
	}

	public Category get(String cate_id) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Category> list() {
		// TODO Auto-generated method stub
		return null;
	}

}
