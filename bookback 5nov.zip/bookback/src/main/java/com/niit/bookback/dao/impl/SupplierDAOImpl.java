package com.niit.bookback.dao.impl;

import java.util.List;

import com.niit.bookback.dao.SupplierDAO;
import com.niit.bookback.model.Supplier;

public class SupplierDAOImpl implements SupplierDAO {

	public boolean save(Supplier supplier) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean update(Supplier supplier) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean delete(Supplier supplier) {
		// TODO Auto-generated method stub
		return false;
	}

	public Supplier get(String supp_id) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Supplier> list() {
		// TODO Auto-generated method stub
		return null;
	}

}
