package com.niit.bookback.dao;

import java.util.List;

import com.niit.bookback.model.Product;

public interface ProductDAO {
	
	public boolean save(Product product);
	
	public boolean update(Product product);
	
	public boolean delete(Product product);
	
	public Product get(String pro_id);
	
	public List<Product> list();
	
	
}
