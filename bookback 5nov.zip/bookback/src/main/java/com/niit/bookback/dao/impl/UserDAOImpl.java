package com.niit.bookback.dao.impl;

import java.util.List;

import com.niit.bookback.dao.UserDAO;
import com.niit.bookback.model.User;

public class UserDAOImpl implements UserDAO {

	public boolean save(User user) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean update(User user) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean delete(User user) {
		// TODO Auto-generated method stub
		return false;
	}

	public User get(String user_id) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<User> list() {
		// TODO Auto-generated method stub
		return null;
	}

}
