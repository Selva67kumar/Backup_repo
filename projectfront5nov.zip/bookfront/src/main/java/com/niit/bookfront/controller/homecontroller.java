package com.niit.bookfront.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class homecontroller {
	
	@RequestMapping("/")
	public String Home(Model model)
	{
		model.addAttribute("para","true");
		return "index";	
	}
	
	@RequestMapping("home")
	public String house(Model model)
	{
		model.addAttribute("para","true");
		return "index";	
	}
	
	@RequestMapping("/category")
	public String category()
	{
		return "category";	
	}
	
		@RequestMapping("/login")
	public String login(Model sel)
	{
		sel.addAttribute("signin","true");
		return "index";	
	}
	
	@RequestMapping("/register")
	public String register(Model model)
	{
		model.addAttribute("signup","true");
		return "index";	
	}
	
	@RequestMapping("/validate")
	public String validate(@RequestParam(name="User Id")String id,@RequestParam(name="password")String pwd,Model model,Model sel)
	{
		if(id.equals("selva") && pwd.equals("hello"))
		{
			model.addAttribute("correct","Sucessfully logged in");
			sel.addAttribute("name",id);
			return "index";
		}
		else
		{
			model.addAttribute("incorrect","Username or password is invalid");
			
			sel.addAttribute("signin","true");
			return "index";
		}
		
	}

}