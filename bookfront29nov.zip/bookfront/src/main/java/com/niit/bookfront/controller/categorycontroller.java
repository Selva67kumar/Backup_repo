package com.niit.bookfront.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.niit.bookback.dao.CategoryDAO;
import com.niit.bookback.model.Category;

@Controller
public class categorycontroller {
	
	static AnnotationConfigApplicationContext ac;
	static private CategoryDAO categoryDAO;
	static {
		ac = new AnnotationConfigApplicationContext();
		ac.scan("com.niit");
		ac.refresh();
		categoryDAO = (CategoryDAO)ac.getBean("CategoryDAO");
	}	
	
	
	
	@ModelAttribute("category")
	public Category getCategory(){
		return new Category();
	}
	
	@RequestMapping(value="/managecategoryadd",method = RequestMethod.POST)
	public String cateadd(@ModelAttribute("category")Category ca){			
			categoryDAO.save(ca);
			return "redirect:/category";
			
	}
	
	@RequestMapping(value="/managecategorydelete",method = RequestMethod.POST)
	public String cateupdate(@ModelAttribute("category")Category ca,Model model){		
			categoryDAO.delete(ca);
			return "redirect:/category";
	}
	@RequestMapping(value="/managecategoryupdate",method = RequestMethod.POST)
	public String catedelete(@ModelAttribute("category")Category ca,Model model){		
			categoryDAO.update(ca);
			return "redirect:/category";
	}
	@RequestMapping(value="/managecategoryview",method = RequestMethod.GET)
	public String cateview(@ModelAttribute("category")Category ca,Model model){		
			categoryDAO.get(ca);
			return "redirect:/category";
	}
	
	

}