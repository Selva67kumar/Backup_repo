package com.niit.bookfront.controller;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.niit.bookback.dao.ProductDAO;
import com.niit.bookback.model.Product;


@Controller
public class productcontroller {
	
  static AnnotationConfigApplicationContext pc;
	static private ProductDAO productDAO;
	static {
		pc = new AnnotationConfigApplicationContext();
		pc.scan("com.niit");
		pc.refresh();
		productDAO = (ProductDAO)pc.getBean("ProductDAO");
	}	
   
	@ModelAttribute("Product")
	public Product getProduct(){
		return new Product();
	}


	
	@RequestMapping(value="/manageproductadd",method = RequestMethod.POST)
	public String cateadd(@ModelAttribute("product")Product ca,Model model){
			productDAO.save(ca);
			return "redirect:/product";
				}
	
	@RequestMapping(value="/manageproductupdate",method = RequestMethod.POST)
	public String cateupdate(@ModelAttribute("product")Product ca,Model model){
			productDAO.update(ca);
			return "redirect:/product";
	}
	
	@RequestMapping(value="/manageproductdelete",method = RequestMethod.POST)
	public String catedelete(@ModelAttribute("product")Product ca,Model model){
			productDAO.delete(ca);
			return "redirect:/product";
	}
	
	@RequestMapping(value = "/manageproductview", method = RequestMethod.GET)
	public String cateview(@ModelAttribute("product")Product ca,Model model) {
		productDAO.get("ca");
		return "redirect:/product";
	}
	
	
}
	


