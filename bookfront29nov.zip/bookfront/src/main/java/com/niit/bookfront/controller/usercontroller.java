/*package com.niit.bookfront.controller;

import javax.enterprise.inject.Model;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.niit.bookback.dao.UserDAO;
import com.niit.bookback.model.User;

@Controller
public class usercontroller {
	
		
		static AnnotationConfigApplicationContext au;
		static private UserDAO userDAO;
		static {
			au = new AnnotationConfigApplicationContext();
			au.scan("com.niit");
			au.refresh();
			userDAO = (UserDAO)au.getBean("UserDAO");
		}	
	   

		@ModelAttribute("user")
		public User getUser(){
			return new User();		
		}

		
		@RequestMapping(value="/manageuser",method = RequestMethod.POST)
		public String cateadd(@RequestParam String add,@ModelAttribute("user")User ca,Model model){
			
			if(add.equals("add")){
				userDAO.save(ca);
				return "redirect:/register";
			}
			return "redirect:/register";
		}
		
		@RequestMapping(value="/manageuser",method = RequestMethod.POST)
		public String cateupdate(@RequestParam String update,@ModelAttribute("user")User ca,Model model){
			
			if(update.equals("update")){
				userDAO.update(ca);
				return "redirect:/register";
			}
			return "redirect:/register";
		}
		
		@RequestMapping(value="/manageuser",method = RequestMethod.POST)
		public String catedelete(@RequestParam String delete,@ModelAttribute("user")User ca,Model model){
			
			if(delete.equals("add")){
				userDAO.delete(ca);
				return "redirect:/register";
			}
			return "redirect:/register";
		}
		
		@RequestMapping(value = "/manageuser", method = RequestMethod.GET)
		public String cateview(@RequestParam String view,@ModelAttribute("user")User ca,Model model) {
			if(view.equals("view")){
			userDAO.get("ca");
			return "redirect:/register";
			}
			return "redirect:/register";
		}
		
		@RequestMapping(value = "/manageuser", method = RequestMethod.GET)
		public String cateviewall(@RequestParam String viewall,@ModelAttribute("user")User ca,Model model) {
			if(viewall.equals("viewall")){
			userDAO.get("ca");
			return "redirect:/register";
			}
			return "redirect:/register";
		}


}
*/