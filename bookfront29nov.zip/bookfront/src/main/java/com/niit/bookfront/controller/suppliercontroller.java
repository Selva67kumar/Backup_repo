package com.niit.bookfront.controller;

import javax.enterprise.inject.Model;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.niit.bookback.dao.SupplierDAO;
import com.niit.bookback.model.Supplier;

@Controller
public class suppliercontroller {
	
	static AnnotationConfigApplicationContext sc;
	static private SupplierDAO supplierDAO;
	static {
		sc = new AnnotationConfigApplicationContext();
		sc.scan("com.niit");
		sc.refresh();
		supplierDAO = (SupplierDAO)sc.getBean("SupplierDAO");
	}	
   

	@ModelAttribute("supplier")
	public Supplier getSupplier(){
		return new Supplier();		
	}

	
	@RequestMapping(value="/managesupplieradd",method = RequestMethod.POST)
	public String suppadd(@ModelAttribute("supplier")Supplier Sa,Model model){
			supplierDAO.save(Sa);
			return "redirect:/supplier";
	}
	
	@RequestMapping(value="/managesupplierupdate",method = RequestMethod.POST)
	public String suppupdate(@ModelAttribute("supplier")Supplier Sa,Model model){
			supplierDAO.update(Sa);
			return "redirect:/supplier";
	}
	
	@RequestMapping(value="/managesupplierdelete",method = RequestMethod.POST)
	public String suppdelete(@ModelAttribute("supplier")Supplier Sa,Model model){
			supplierDAO.delete(Sa);
			return "redirect:/supplier";
	}
	
	@RequestMapping(value = "/managesupplierview", method = RequestMethod.GET)
	public String suppview(@ModelAttribute("supplier")Supplier Sa,Model model) {
		supplierDAO.get(getSupplier());
		return "redirect:/supplier";
		}
	
	
/*@RequestMapping(value = "/managesupplier", method = RequestMethod.GET)
	*public String cateviewall(@RequestParam String viewall,@ModelAttribute("supplier")Supplier ca,Model model) {
	*	if(viewall.equals("viewall")){
	*	supplierDAO.get("ca");
	*	return "redirect:/supplier";
	*	}
	*	return "redirect:/supplier";
	}*/

	

}
