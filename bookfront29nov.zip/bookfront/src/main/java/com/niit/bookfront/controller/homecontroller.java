package com.niit.bookfront.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.bookback.dao.CategoryDAO;
import com.niit.bookback.dao.ProductDAO;
import com.niit.bookback.dao.SupplierDAO;
import com.niit.bookback.model.Category;
import com.niit.bookback.model.Product;
import com.niit.bookback.model.Supplier;

@Controller
public class homecontroller {

	static AnnotationConfigApplicationContext ac;
	static private CategoryDAO categoryDAO;
	static private ProductDAO productDAO;
	static private SupplierDAO supplierDAO;
	static {
		ac = new AnnotationConfigApplicationContext();
		ac.scan("com.niit");
		ac.refresh();
		categoryDAO = (CategoryDAO)ac.getBean("CategoryDAO");
		productDAO = (ProductDAO)ac.getBean("ProductDAO");
		supplierDAO = (SupplierDAO)ac.getBean("SupplierDAO");
	}	
	
	/*static AnnotationConfigApplicationContext pc;
	static private ProductDAO productDAO;
	static {
		pc = new AnnotationConfigApplicationContext();
		pc.scan("com.niit");
		pc.refresh();
		productDAO = (ProductDAO)pc.getBean("ProductDAO");
	}
	
	static AnnotationConfigApplicationContext sc;
	static private SupplierDAO supplierDAO;
	static {
		sc = new AnnotationConfigApplicationContext();
		sc.scan("com.niit");
		sc.refresh();
		supplierDAO = (SupplierDAO)sc.getBean("SupplierDAO");
	}
	*/
	@ModelAttribute("category")
	public Category getCategory(){
		return new Category();
	}

	@ModelAttribute("product")
	public Product getProduct(){
		return new Product();
	}	
	
	@ModelAttribute("supplier")
	public Supplier getSupplier(){
		return new Supplier();
	}
	
	
	@RequestMapping("/")
	public ModelAndView Home(Model model)
	{
		ModelAndView mv = new ModelAndView("redirect:/home");
		model.addAttribute("para","true");
		model.addAttribute("logout", "true");
		return mv;	
	}
	
	@RequestMapping("/logout")
	public String logout(Model model)
	{
		model.addAttribute("para","true");
		model.addAttribute("logout","true");
		return "index";
	}
	
	@RequestMapping("/home")
	public String house(Model model,@ModelAttribute("category")Category category,HttpSession session)
	{
		session.setAttribute("category", category);
		session.setAttribute("categoryList", categoryDAO.list());
		model.addAttribute("logout","true");
		model.addAttribute("para","true");
		return "index";	
	}
	
	@RequestMapping("/category")
	public String category(Model model)
	{
		model.addAttribute("loggin","true");
		model.addAttribute("cate","true");
		return "index";	
	}
	
	@RequestMapping("/supplier")
	public String supplier(@ModelAttribute("supplier")Supplier supplier,Model model,HttpSession session)
	{
				
		model.addAttribute("loggin","true");
		model.addAttribute("supp","true");
		return "index";	
	}
	
	@RequestMapping("/product")
	public String product(Model model)
	{
	
		model.addAttribute("loggin","true");
		model.addAttribute("pro","true");
		return "index";	
	}
	
		@RequestMapping("/login")
	public String login(Model model)
	{
			model.addAttribute("logout","true");
			model.addAttribute("signin","true");
		return "index";	
	}
	
	@RequestMapping("/register")
	public String register(Model model)
	{
		model.addAttribute("logout","true");
		model.addAttribute("signup","true");
		return "index";	
	}
	

	@RequestMapping("/validate")
	public String validate(@RequestParam(name="User Id")String id,@RequestParam(name="password")String pwd,Model model)
	{
		if(id.equals("selva") && pwd.equals("hello"))
		{
			model.addAttribute("correct","Sucessfully logged in");
			model.addAttribute("loggin","true");
			model.addAttribute("name",id);
			return "index";
		}
		else
		{
			model.addAttribute("incorrect","Username or password is invalid");
			
			model.addAttribute("signin","true");
			return "index";
		}
		
	}

}