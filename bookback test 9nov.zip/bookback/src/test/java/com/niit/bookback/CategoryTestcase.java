package com.niit.bookback;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import com.niit.bookback.dao.CategoryDAO;
import com.niit.bookback.model.Category;


public class CategoryTestcase {
	
	@Autowired
	static AnnotationConfigApplicationContext context;
	
	@Autowired
	static Category category;
	
	@Autowired
	static CategoryDAO categoryDAO;

	@BeforeClass 
	public static void init() {
		context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.bookback");
		context.refresh();
		
		categoryDAO = (CategoryDAO) context.getBean("categoryDAO");
		
		category = (Category) context.getBean("category");
	}
	
	@Test
	public void createCategoryTestCase()
	{
	
		category.setCate_id("cate 01");
		category.setCate_name("Tintin");
		category.setCate_description("First Category");
		
		Boolean status = categoryDAO.save(category);
		Assert.assertEquals("Sucessfully Created", true, status);
	}
	
	@Test
	public void deleteCategoryTestCase()
	{
		category.setCate_id("cate_02");
		boolean status = categoryDAO.delete(category);
		
		Assert.assertEquals("Delete Category Test case", true, status);
	}
	
	@Test
	public void updateCategoryTestcase()
	{
		category.setCate_id("cate 01");
		category.setCate_description("Its is a noddy cartoon");
		
		Boolean status = categoryDAO.update(category);
		
		Assert.assertEquals("Updating the columns", true, status);
	}

}
