package com.niit.bookback.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table
@Component
public class Supplier {
	
	
	private String Supp_id;
	private String Supp_name;
	private String Supp_address;
	@Id
	public String getSupp_id() {
		return Supp_id;
	}
	public void setSupp_id(String supp_id) {
		Supp_id = supp_id;
	}
	public String getSupp_name() {
		return Supp_name;
	}
	public void setSupp_name(String supp_name) {
		Supp_name = supp_name;
	}
	public String getSupp_address() {
		return Supp_address;
	}
	public void setSupp_address(String supp_address) {
		Supp_address = supp_address;
	}
	
	
	

}
