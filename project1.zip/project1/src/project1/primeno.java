package project1;
import java.util.Scanner;

public class primeno {

public static void main(String arg[]){
	int a,b,i,j=0;
	Scanner s = new Scanner(System.in);
	a=s.nextInt();
	for(i=2;i<a;i++){
		b=a%i;
	if(b==0){
		System.out.println("The number is not a prime number");
		j=1;
		break;
	}
	}
	if(j==0)
	System.out.println("The is number is a prime number");
	

}
}