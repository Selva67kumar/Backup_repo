/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package javaapplication1;
import java.util.Scanner;
/**
 *
 * @author Dashing Selva
 */
public class harmonicprogress {
    public static void main(String arg[]){
        int a,b,c,i,d,e;
    Scanner s=new Scanner(System.in);
    System.out.println("Enter the first number of sequence");
       a=s.nextInt();
   System.out.println("Enter the common difference of sequence");
        b=s.nextInt();
   System.out.println("Enter the no. of terms of sequence");
        c=s.nextInt();
   System.out.println("The Sequence is  :  ");
        for(i=0;i<c;i++){
            e=b*i;
       d=a+e;
   System.out.print("1/"+d+",");
        }
        
        
        
        
    }
}
