/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package javaapplication1;
import java.util.Scanner;
/**
 *
 * @author Dashing Selva
 */
public class Fabonacci {
public static void main(String arg[]){
      
  int a,b,c,i,j;
      Scanner s=new Scanner(System.in);
    System.out.println("Enter first no. of Fabanocci Series :");
      a=s.nextInt();
    System.out.println("Enter Second no. of Fabanocci Series :");  
      b=s.nextInt();
    System.out.println("Enter the no. of terms in your Fabanocci Series :");
      c=s.nextInt();
    System.out.println("");  
    System.out.print("Your Fabanocci Series is : "+a+","+b);
          for(i=2;i<c;i++){
              j=b+a;
              System.out.print(",");
              System.out.print(""+j);
          }
      
    
    
    
}    
}
