/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package javaapplication1;

/**
 *
 * @author Dashing Selva
 */
import java.util.*;
import java.lang.*;

public class geometricprogress {
 
    public static void main(String arg[]){
        
    double i,j,k,a,b,c;
       Scanner s=new Scanner(System.in);
    System.out.println("Enter the first element of Geometric Progession");
       i=s.nextInt();
    System.out.println("Enter the common ratio of Geometric Progession");
       j=s.nextInt();
    System.out.println("Enter the elements you want in this Geometric Progession");
       k=s.nextInt();
    System.out.println("The Geometric progression is : ");
    System.out.println("");
       for(a=0;a<k;a++){
        b=Math.pow(j,a);
        c=i*b;
        System.out.print(" "+c);
       }
       
    }
}
