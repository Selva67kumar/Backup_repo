package com.niit.bookback.dao;

import java.util.List;

import com.niit.bookback.model.User;

public interface UserDAO {
	
	public boolean save(User user);
	
	public boolean update(User user);
	
	public boolean delete(User user);
	
	public User get(String userid);
	
	public boolean validate(String name,String pwd);
	
	public List<User> list();

}
