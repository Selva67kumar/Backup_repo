package com.niit.bookback.dao;

import java.util.List;

import com.niit.bookback.model.Cart;


public interface CartDAO {
	
	public boolean save(Cart cart);
	
	public boolean delete(Cart cart);
	
	public int sum(Cart cart);
	
	public boolean trun();
	
	public List<Cart> list();
}
