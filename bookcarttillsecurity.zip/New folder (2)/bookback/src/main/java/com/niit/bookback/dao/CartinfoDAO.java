package com.niit.bookback.dao;

import java.util.List;

import com.niit.bookback.model.Cartinfo;

public interface CartinfoDAO {
	
	public boolean listcopy();

	public List<Cartinfo> list();
}
