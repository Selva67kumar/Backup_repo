package com.niit.bookback.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

@Entity
@Table(name="product")
@Component
public class Product {
	
	@Id
	private String pro_id;
	private String pro_name;
	private String pro_author;
	

	private String pro_price;
	private String cate_id;
	private String supp_id;
	@Transient
	MultipartFile file;
	
	
	public String getPro_id() {
		return pro_id;
	}
	
	public void setPro_id(String pro_id) {
		this.pro_id = pro_id;
	}
	
	public String getPro_name() {
		return pro_name;
	}
	public void setPro_name(String pro_name) {
		this.pro_name = pro_name;
	}
	public String getPro_price() {
		return pro_price;
	}
	public void setPro_price(String pro_price) {
		this.pro_price = pro_price;
	}
	public String getCate_id() {
		return cate_id;
	}
	public void setCate_id(String cate_id) {
		this.cate_id = cate_id;
	}
	public String getSupp_id() {
		return supp_id;
	}
	public void setSupp_id(String supp_id) {
		this.supp_id = supp_id;
	}

	public String getPro_author() {
		return pro_author;
	}

	public void setPro_author(String pro_author) {
		this.pro_author = pro_author;
	}
	public MultipartFile getFile() {
	return file;
	}
	
	//public void setFile(MultipartFile file){
	//this.file = file;
	//}
}
