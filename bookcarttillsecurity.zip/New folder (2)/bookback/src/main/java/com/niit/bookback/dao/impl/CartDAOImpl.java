package com.niit.bookback.dao.impl;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.bookback.dao.CartDAO;
import com.niit.bookback.model.Cart;


@Repository("cartDAO")
public class CartDAOImpl implements CartDAO{
	
	@Autowired
	SessionFactory sessionFactory;
	
	public CartDAOImpl(){};
	public CartDAOImpl(SessionFactory sessionFactory)
	{
		this.sessionFactory=sessionFactory;
	}
	

	@Transactional
	public boolean save(Cart cart) {
		try {
			sessionFactory.getCurrentSession().save(cart);
			return true;
		} catch (HibernateException e) {
			e.printStackTrace();
			return false;
		}
		
	}

	@Transactional
	public boolean delete(Cart cart) {
		try {
			sessionFactory.getCurrentSession().delete(cart);
			return true;
		} catch (HibernateException e) {
			e.printStackTrace();
			return false;
		}
	}

	/*@Transactional
	public Cart get(String srno) {
		return (Cart) sessionFactory.getCurrentSession().get(Cart.class,srno);
	}*/

	@Transactional
	public boolean trun() {
		
		String hql = "TRUNCATE TABLE Cart";
		Query query = sessionFactory.getCurrentSession().createSQLQuery(hql);
		query.executeUpdate();
		return true;
	}
	
	
	
	@Transactional
	public List<Cart> list() {
		
		String hql = "from Cart";
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		
		return query.list();
	}
	
	@Transactional
	public int sum(Cart cart) {
		
		String hql = "select sum(pro_price) from Cart";
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		List listResult = query.list();
		Number number = (Number)listResult.get(0);
		return number.intValue();
	}
	
	
	
}
