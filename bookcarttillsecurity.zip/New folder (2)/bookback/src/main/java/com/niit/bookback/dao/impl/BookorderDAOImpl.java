package com.niit.bookback.dao.impl;


import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.bookback.dao.BookorderDAO;
import com.niit.bookback.model.Bookorder;


@Repository("bookDAO")
public class BookorderDAOImpl implements BookorderDAO{
	
	@Autowired
	SessionFactory sessionFactory;
	
	public BookorderDAOImpl(){};
	public BookorderDAOImpl(SessionFactory sessionFactory)
	{
			this.sessionFactory=sessionFactory;
	}
	
	@Transactional
	public boolean save(Bookorder bookorder) {
		try{
			sessionFactory.getCurrentSession().save(bookorder);
			return true;
		}
		catch(Exception e){
			e.printStackTrace();
			return false;
		}
	}
	
	@Transactional
	public boolean delete(Bookorder bookorder) {
		try{
			sessionFactory.getCurrentSession().delete(bookorder);
			return true;
		}
		catch(Exception e){
			e.printStackTrace();
			return false;
		}
		
	}
	
	@Transactional
	public Bookorder get(String order_id) {
		return (Bookorder) sessionFactory.getCurrentSession().get(Bookorder.class,order_id);
	}

}
