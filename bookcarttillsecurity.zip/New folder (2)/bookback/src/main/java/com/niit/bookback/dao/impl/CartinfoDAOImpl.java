package com.niit.bookback.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.bookback.dao.CartinfoDAO;
import com.niit.bookback.model.Cartinfo;


	@Repository("cartinfoDAO")
	public class CartinfoDAOImpl implements CartinfoDAO {

		@Autowired
		SessionFactory sessionFactory;
		
		public CartinfoDAOImpl(){};
		public CartinfoDAOImpl(SessionFactory sessionFactory)
		{
			this.sessionFactory=sessionFactory;
		}
		
		@Transactional
		public boolean listcopy(){
			String hql = "INSERT INTO cartinfo SELECT userid_date,pro_id,pro_price FROM cart";
			Query query = sessionFactory.getCurrentSession().createSQLQuery(hql);
			query.executeUpdate();
			return true;
		}
	
		@Transactional
		public List<Cartinfo> list() {
			String hql = "from Cartinfo";
			Query query = sessionFactory.getCurrentSession().createQuery(hql);
			
			return query.list();
		}
}
