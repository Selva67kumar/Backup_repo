package com.niit.bookback.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table
@Component
public class Cart {

@Id
String srno;	
String user_id;
String pro_id;
int pro_price;
String pro_name;
String userid_date;

public String getPro_name() {
	return pro_name;
}
public void setPro_name(String pro_name) {
	this.pro_name = pro_name;
}
public String getSrno() {
	return srno;
}
public void setSrno(String srno) {
	this.srno = srno;
}

public String getUserid_date() {
	return userid_date;
}
public void setUserid_date(String userid_date) {
	this.userid_date = userid_date;
}


public String getUser_id() {
	return user_id;
}
public void setUser_id(String user_id) {
	this.user_id = user_id;
}
public String getPro_id() {
	return pro_id;
}
public void setPro_id(String pro_id) {
	this.pro_id = pro_id;
}
public int getPro_price() {
	return pro_price;
}
public void setPro_price(int pro_price) {
	this.pro_price = pro_price;
}

	
}
