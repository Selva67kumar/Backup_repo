package com.niit.bookback.model;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table
@Component
public class Cartinfo {

	String userid_date;
	String pro_id;
	int pro_price;
	
	public String getUserid_date() {
		return userid_date;
	}
	public void setUserid_date(String userid_date) {
		this.userid_date = userid_date;
	}
	public String getPro_id() {
		return pro_id;
	}
	public void setPro_id(String pro_id) {
		this.pro_id = pro_id;
	}
	public int getPro_price() {
		return pro_price;
	}
	public void setPro_price(int pro_price) {
		this.pro_price = pro_price;
	}

	
	
}
