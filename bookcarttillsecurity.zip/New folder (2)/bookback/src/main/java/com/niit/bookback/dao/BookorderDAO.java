package com.niit.bookback.dao;

import com.niit.bookback.model.Bookorder;

public interface BookorderDAO {
	
public boolean save(Bookorder bookorder);
	
	public boolean delete(Bookorder bookorder);
	
	public Bookorder get(String id);

}
