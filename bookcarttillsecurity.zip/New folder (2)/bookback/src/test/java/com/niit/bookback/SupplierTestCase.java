/*package com.niit.bookback;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.bookback.dao.SupplierDAO;
import com.niit.bookback.model.Supplier;

public class SupplierTestCase {

	@Autowired
	static AnnotationConfigApplicationContext context;
	
	@Autowired
	static Supplier supplier;
	
	@Autowired
	static SupplierDAO supplierDAO;

	@BeforeClass 
	public static void init() {
		context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.bookback");
		context.refresh();
		
		supplierDAO = (SupplierDAO) context.getBean("supplierDAO");
		
		supplier = (Supplier) context.getBean("supplier");
	}
	
	@Test
	public void createSupplierTestCase()
	{
	
		supplier.setSupp_id("supp 01");
		supplier.setSupp_name("Supplier 1");
		supplier.setSupp_address("Supplier address 1");
		
		Boolean status = supplierDAO.save(supplier);
		Assert.assertEquals("Supplier Sucessfully Added", true, status);
	}
	
	@Test
	public void deleteSupplierTestCase()
	{
		supplier.setSupp_id("supp 01");
		boolean status = supplierDAO.delete(supplier);
		
		Assert.assertEquals("Delete Supplier Test case", true, status);
	}
	
	@Test
	public void updateSupplierTestcase()
	{
		supplier.setSupp_id("supp id");
		supplier.setSupp_address("chennai");
		
		Boolean status = supplierDAO.update(supplier);
		
		Assert.assertEquals("changing the supplier columns", true, status);
	}



}
*/