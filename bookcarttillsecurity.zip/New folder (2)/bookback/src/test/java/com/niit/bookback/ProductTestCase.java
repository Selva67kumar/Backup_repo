/*package com.niit.bookback;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.bookback.dao.ProductDAO;
import com.niit.bookback.model.Product;

public class ProductTestCase {
	
	@Autowired
	static AnnotationConfigApplicationContext context;
	
	@Autowired
	static Product product;
	
	@Autowired
	static ProductDAO productDAO;

	@BeforeClass 
	public static void init() {
		context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.bookback");
		context.refresh();
		
		productDAO = (ProductDAO) context.getBean("productDAO");
		
		product = (Product) context.getBean("product");
	}
	
	@Test
	public void createProductTestCase()
	{
	
		product.setCate_id("pro 1");
		product.setPro_name("Product 1");
		product.setPro_price("2000");
		product.setCate_id("cate 01");
		product.setSupp_id("supp 01");
		
		Boolean status = productDAO.save(product);
		Assert.assertEquals("Sucessfully Created", true, status);
	}
	
	@Test
	public void deleteProductTestCase()
	{
		product.setPro_id("Pro 01");
		boolean status = productDAO.delete(product);
		
		Assert.assertEquals("Delete Product Test case", true, status);
	}
	
	@Test
	public void updateProductTestcase()
	{
		product.setPro_id("Pro 01");;
		product.setPro_price("5000");
		
		Boolean status = productDAO.update(product);
		
		Assert.assertEquals("Updating the columns", true, status);
	}


}
*/