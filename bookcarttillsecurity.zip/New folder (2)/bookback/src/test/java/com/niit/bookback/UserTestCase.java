/*package com.niit.bookback;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.bookback.dao.UserDAO;
import com.niit.bookback.model.User;

public class UserTestCase {

	@Autowired
	static AnnotationConfigApplicationContext context;
	
	@Autowired
	static User user;
	
	@Autowired
	static UserDAO userDAO;

	@BeforeClass 
	public static void init() {
		context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.bookback");
		context.refresh();
		
		userDAO = (UserDAO) context.getBean("userDAO");
		
		user = (User) context.getBean("user");
	}
	
	@Test
	public void createUserTestCase()
	{
	
		user.setUser_id("user 1");
		user.setUser_name("User name1");
		user.setUser_add("User address1");
		user.setUser_pwd("hello");
		user.setUser_con("7402226469");
		
		
		Boolean status = userDAO.save(user);
		Assert.assertEquals("Sucessfully Created", true, status);
	}

}
*/