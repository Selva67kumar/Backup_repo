package com.niit.bookfront.controller;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.niit.bookback.dao.CategoryDAO;
import com.niit.bookback.model.Category;

@Controller
public class categorycontroller {
	
	static AnnotationConfigApplicationContext ac;
	static private CategoryDAO categoryDAO;
	static {
		ac = new AnnotationConfigApplicationContext();
		ac.scan("com.niit");
		ac.refresh();
		categoryDAO = (CategoryDAO)ac.getBean("CategoryDAO");
	}	
	
	
	
	@ModelAttribute("category")
	public Category getCategory(){
		return new Category();
	}
	
	@RequestMapping(value="/adminmanagecategoryadd",method = RequestMethod.POST)
	public String cateadd(@ModelAttribute("category")Category ca,Model model){			
			try{
				categoryDAO.save(ca);
			model.addAttribute("viewc","false");
			model.addAttribute("report","Saved Sucessfully");
			}
			
			catch(Exception e){
				model.addAttribute("report","Not saved maybe record exist");	
			}
			return "redirect:/admincategory";
	}
	
	@RequestMapping(value="/adminmanagecategorydelete",method = RequestMethod.POST)
	public String cateupdate(@ModelAttribute("category")Category ca,Model model){		
			try{
			categoryDAO.update(ca);
			model.addAttribute("viewc","false");
			model.addAttribute("report","Updated Sucessfully");
			}
			catch(Exception e){
				model.addAttribute("report","Cannot be updated");
			}
			return "redirect:/admincategory";
	}
	@RequestMapping(value="/adminmanagecategoryupdate",method = RequestMethod.POST)
	public String catedelete(@ModelAttribute("category")Category ca,Model model){		
			try{
				categoryDAO.delete(ca);
				model.addAttribute("viewc","false");
				model.addAttribute("report","Deleted Sucessfully");
			}
			catch(Exception e){
				model.addAttribute("report","Error: Oops category not found with this Id");
			}
			return "redirect:/admincategory";
	}
	/*@RequestMapping(value="/managecategoryview",method = RequestMethod.GET)
	public String cateview(@ModelAttribute("category")Category ca,Model model){		
			try{
				Category g=categoryDAO.get(ca.getCate_id());
				model.addAttribute("viewcate",g);
				model.addAttribute("viewc","true");
			}
			catch(Exception e){
				model.addAttribute("report","Invalid ID");
			}
			return "redirect:/category";
	}*/
	
	

}