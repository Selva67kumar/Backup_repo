package com.niit.bookfront.controller;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.niit.bookback.dao.BookorderDAO;
import com.niit.bookback.model.Bookorder;
import com.niit.bookback.model.Product;


@Controller
public class ordercontroller {

	static AnnotationConfigApplicationContext ac;
	static private BookorderDAO bookorderDAO;
	static {
		ac = new AnnotationConfigApplicationContext();
		ac.scan("com.niit");
		ac.refresh();
		bookorderDAO = (BookorderDAO)ac.getBean("BookorderDAO");
	}	
	
	
	
	@ModelAttribute("Bookorder")
	public Bookorder getBookorder(){
		return new Bookorder();
	}
	
	@RequestMapping(value="/usercancelorder",method = RequestMethod.POST)
	public String orcancel(@ModelAttribute("bookorder")Bookorder ca,Model model){
			try{
				bookorderDAO.delete(ca);
				model.addAttribute("ortt","true");
				model.addAttribute("para","true");
				model.addAttribute("orderreport","Cancelled Sucessfully");
			}
			catch(Exception e){
				model.addAttribute("orderreport","Oops order not found");
			}
			return "index";
	}
	@RequestMapping(value="/userstatusorder",method = RequestMethod.GET)
	public String orget(@ModelAttribute("bookorder")Bookorder ca,Model model){
			try{
				Bookorder b=bookorderDAO.get(ca.getOrder_id());
				model.addAttribute("ortt","true");
				model.addAttribute("para","true");
				model.addAttribute("orderreport",b.getStatus());
			}
			catch(Exception e){
				model.addAttribute("orderreport","Oops order not found");
			}
			return "index";
	}
	
	
}
