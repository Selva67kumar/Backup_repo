package com.niit.bookfront.controller;


import javax.servlet.http.HttpSession;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.niit.bookback.dao.UserDAO;
import com.niit.bookback.model.Product;
import com.niit.bookback.model.User;

@Controller
public class usercontroller {
	
		
		static AnnotationConfigApplicationContext ac;
		static private UserDAO userDAO;
		static {
			ac = new AnnotationConfigApplicationContext();
			ac.scan("com.niit");
			ac.refresh();
			userDAO = (UserDAO)ac.getBean("UserDAO");
		}	
	   

		@ModelAttribute("user")
		public User getUser(){
			return new User();		
		}

		
		@RequestMapping(value="/manageuseradd",method = RequestMethod.POST)
		public String cateadd(@ModelAttribute("user")User ca,HttpSession session){

				userDAO.save(ca);
				return "redirect:/login";

		}
		
		@RequestMapping(value = "/validate", method = RequestMethod.POST)
		public String proview(@ModelAttribute("user")User ca,Model model,HttpSession session) {
			User p = userDAO.get(ca.getUser_id());
			if(ca.getUser_pwd().equals(p.getUser_pwd())){
			
				if(p.getUser_role().equals("admin")){
					session.setAttribute("admin","true");
				}
				else{
					session.setAttribute("admin", "false");
				}
				session.setAttribute("loggedin","true");
				session.setAttribute("name",p.getUser_name());
				session.setAttribute("userid",p.getUser_id());
				session.setAttribute("Address",p.getUser_add());
				return "index";
				
			}
			else{
				
				model.addAttribute("incorrect","Username or password is invalid");
				return "redirect:/login";
				
			}
				
		}
		/*@RequestMapping(value="/manageuser",method = RequestMethod.POST)
		public String cateupdate(@RequestParam String update,@ModelAttribute("user")User ca,Model model){
			
			if(update.equals("update")){
				userDAO.update(ca);
				return "redirect:/register";
			}
			return "redirect:/register";
		}
		
		@RequestMapping(value="/manageuser",method = RequestMethod.POST)
		public String catedelete(@RequestParam String delete,@ModelAttribute("user")User ca,Model model){
			
			if(delete.equals("add")){
				userDAO.delete(ca);
				return "redirect:/register";
			}
			return "redirect:/register";
		}
		
		@RequestMapping(value = "/manageuser", method = RequestMethod.GET)
		public String cateview(@RequestParam String view,@ModelAttribute("user")User ca,Model model) {
			if(view.equals("view")){
			userDAO.get("ca");
			return "redirect:/register";
			}
			return "redirect:/register";
		}
		
		@RequestMapping(value = "/manageuser", method = RequestMethod.GET)
		public String cateviewall(@RequestParam String viewall,@ModelAttribute("user")User ca,Model model) {
			if(viewall.equals("viewall")){
			userDAO.get("ca");
			return "redirect:/register";
			}
			return "redirect:/register";
		}
*/

}
