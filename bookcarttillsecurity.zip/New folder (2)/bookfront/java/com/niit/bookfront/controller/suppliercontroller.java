package com.niit.bookfront.controller;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.niit.bookback.dao.SupplierDAO;
import com.niit.bookback.model.Supplier;

@Controller
public class suppliercontroller {
	
	static AnnotationConfigApplicationContext ac;
	static private SupplierDAO supplierDAO;
	static {
		ac = new AnnotationConfigApplicationContext();
		ac.scan("com.niit");
		ac.refresh();
		supplierDAO = (SupplierDAO)ac.getBean("SupplierDAO");
	}	
   

	@ModelAttribute("supplier")
	public Supplier getSupplier(){
		return new Supplier();		
	}

	
	@RequestMapping(value="/adminmanagesupplieradd",method = RequestMethod.POST)
	public String suppadd(@ModelAttribute("supplier")Supplier Sa,Model model){
			try{
				supplierDAO.save(Sa);
			model.addAttribute("views","false");
			model.addAttribute("report","Saved Sucessfully");
			}
			catch(Exception e){
				model.addAttribute("report","Not saved maybe record exist");	
			}
			return "redirect:/adminsupplier";
	}
	
	@RequestMapping(value="/adminmanagesupplierupdate",method = RequestMethod.POST)
	public String suppupdate(@ModelAttribute("supplier")Supplier Sa,Model model){
			try{
				supplierDAO.update(Sa);
			model.addAttribute("views","false");
			model.addAttribute("report","Updated Sucessfully");
			}
			catch(Exception e){
				model.addAttribute("report","Cannot be updated");
			}
			return "redirect:/adminsupplier";
	}
	
	@RequestMapping(value="/adminmanagesupplierdelete",method = RequestMethod.POST)
	public String suppdelete(@ModelAttribute("supplier")Supplier Sa,Model model){
			try{
				supplierDAO.delete(Sa);
				model.addAttribute("views","false");
				model.addAttribute("report","Deleted Sucessfully");
				}
			catch(Exception e){
				model.addAttribute("report","Error: Oops supplier not found with this Id");
			}
			return "redirect:/adminsupplier";
	}
	
	/*@RequestMapping(value = "/managesupplierview", method = RequestMethod.GET)
	public String suppview(@ModelAttribute("supplier")Supplier Sa,Model model) {
		Supplier s = supplierDAO.get(Sa.getSupp_id());
		model.addAttribute("viewsup",s);
		model.addAttribute("views","true");
		return "redirect:/supplier";
		}
	*/
	

}
