package com.niit.bookfront.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.servlet.http.HttpSession;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.niit.bookback.dao.BookorderDAO;
import com.niit.bookback.dao.CartDAO;
import com.niit.bookback.dao.CartinfoDAO;
import com.niit.bookback.dao.CartinfoDAO;
import com.niit.bookback.model.Bookorder;
import com.niit.bookback.model.Cart;
import com.niit.bookback.model.Cartinfo;
import com.niit.bookback.model.Cartinfo;
import com.niit.bookback.model.User;


@Controller
public class purchasecontroller {

	static AnnotationConfigApplicationContext ac;
	static private CartDAO cartDAO;
	static private BookorderDAO bookorderDAO;
	static private CartinfoDAO cartinfoDAO;
	static {
		ac = new AnnotationConfigApplicationContext();
		ac.scan("com.niit");
		ac.refresh();
		cartDAO = (CartDAO)ac.getBean("CartDAO");
		bookorderDAO = (BookorderDAO)ac.getBean("BookorderDAO");
		cartinfoDAO = (CartinfoDAO)ac.getBean("CartinfoDAO");
	}	
		
	@ModelAttribute("cart")
	public Cart getCart(){
		return new Cart();
	}
	
	
	@ModelAttribute("bookorder")
	public Bookorder getBookorder(){
		return new Bookorder();
	}
	
	@RequestMapping("/usergomycart")
	public String cart(Model model,@ModelAttribute("cart")Cart cart,HttpSession session)
	{

		try{
		DateTimeFormatter heltime = DateTimeFormatter.ofPattern("yyyyMMdd");
		LocalDate localDate = LocalDate.now();
		session.setAttribute("orderid",heltime.format(localDate));
		session.setAttribute("cart",cart);
		session.setAttribute("cartList",cartDAO.list());
		model.addAttribute("totalprice",cartDAO.sum(cart));
		}
		catch(NullPointerException e){
			
		}
		model.addAttribute("address","true");
		return "index";	
	}
	
	@RequestMapping(value="/useraddtocart",method = RequestMethod.POST)
	public String cartadd(@ModelAttribute("cart")Cart ca,Model model){			
			try{
				cartDAO.save(ca);
				}
			catch(Exception e){					
			}
			return "redirect:/";
	}
	
	@RequestMapping(value="/usercartdelete",method = RequestMethod.POST)
	public String cartdel(@ModelAttribute("cart")Cart ca,Model model){			
			try{
				cartDAO.delete(ca);
				}
			catch(Exception e){
				return "redirect:/";
			}
			
			return "redirect:/usergomycart";
	}
	
	@RequestMapping(value="/userconfirmorder",method = RequestMethod.POST)
	public String orderadd(@ModelAttribute("bookorder")Bookorder bo,Model model){			
			try{
				bookorderDAO.save(bo);
				cartinfoDAO.listcopy();
				cartDAO.trun();
				}
			catch(Exception e){	
				System.out.println("hello"+e);
			}
			return "purchase";
	}
	
	@RequestMapping(value="/userpayment",method = RequestMethod.POST)
	public String paymment(){
		return "captcha";
	}
	
	
	
	@RequestMapping(value="/userdetails",method = RequestMethod.GET)
	public String cartdel(@RequestParam(name="captch")String capt,@ModelAttribute("bookorder")Bookorder bo,Model model){			
			if(capt.equals("CAPTCHA")){
				Bookorder p = bookorderDAO.get(bo.getOrder_id());
				model.addAttribute("ordno",p.getOrder_id());
				model.addAttribute("addr",p.getAddress());
				model.addAttribute("usidda",p.getUserid_date());
				model.addAttribute("pri",p.getOrder_price());
				
			return "final";	
			}
			else{
			return "captcha";
			}
	}
	
	
	
	

}
