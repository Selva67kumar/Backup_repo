package com.niit.bookfront.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.fileupload.FileUpload;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.niit.bookback.dao.ProductDAO;
import com.niit.bookback.model.Product;



@Controller
public class productcontroller {
	
  static AnnotationConfigApplicationContext ac;
	static private ProductDAO productDAO;
	static {
		ac = new AnnotationConfigApplicationContext();
		ac.scan("com.niit");
		ac.refresh();
		productDAO = (ProductDAO)ac.getBean("ProductDAO");
	}	
   
	@ModelAttribute("Product")
	public Product getProduct(){
		return new Product();
	}
	
	/*public FileUploadController(){
		setCommandClass(FileUpload.class);
		setCommandName("fileUploadForm");
	}*/

	
	@RequestMapping(value="/adminmanageproductadd",method = RequestMethod.GET)
	public String proadd(@ModelAttribute("product")Product ca,Model model,HttpServletRequest req,@RequestParam("pro_id")String proid){
			try{
				productDAO.save(ca);
				String a=req.getRealPath("/");
			model.addAttribute("viewp","false");
			model.addAttribute("report","Saved Sucessfully");
			System.out.println(a);
			String saveDirectory = a+"resource/images/";
			FileOutputStream outputStream = null;

			//MultipartFile file = ca.getFile();
			try{ 
				//if (!file.isEmpty()) {
					outputStream = new FileOutputStream(new File(saveDirectory +proid+".jpg"));
					
					System.out.println(saveDirectory +proid+".jpg");
					outputStream.close();

		            //file.transferTo(new File(saveDirectory +proid+".jpg"));
		        //}
				//else{
					//System.out.println("empty file.....");
				//}
			}
			catch(Exception e){
				System.out.println(e);
			}
			}
			catch(Exception e){
				System.out.println(e);
				model.addAttribute("report","Not saved maybe record exist");	
			}
			return "redirect:/adminproduct";
				}
	@RequestMapping(value="/adminmanageproductupdate",method = RequestMethod.POST)
	public String proupdate(@ModelAttribute("product")Product ca,Model model){
			try{
				productDAO.update(ca);
			    model.addAttribute("viewp","false");
			    model.addAttribute("report","Updated Sucessfully");
			}
			catch(Exception e){
				model.addAttribute("report","Cannot be updated");
			}
			return "redirect:/adminproduct";
	}
	
	@RequestMapping(value="/adminmanageproductdelete",method = RequestMethod.POST)
	public String prodelete(@ModelAttribute("product")Product ca,Model model){
			try{
				productDAO.delete(ca);
				model.addAttribute("viewp","false");
				model.addAttribute("report","Deleted Sucessfully");
			}
			catch(Exception e){
				model.addAttribute("report","Error: Oops product not found with this Id");
			}
			return "redirect:/adminproduct";
	}
	
	@RequestMapping(value = "/adminmanageproductview", method = RequestMethod.GET)
	public String proview(@ModelAttribute("product")Product ca,Model model) {
		try{
			Product p = productDAO.get(ca.getPro_id());
			model.addAttribute("viewpro",p);
			model.addAttribute("viewp","true");
			}
		catch(Exception e){
			model.addAttribute("report","Invalid ID");
		}
		return "redirect:/adminproduct";
	}
	
	
}
	


