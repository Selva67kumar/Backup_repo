package com.niit.bookback.dao.impl;

import java.util.List;

import com.niit.bookback.dao.ProductDAO;
import com.niit.bookback.model.Product;

public class ProductDAOImpl implements ProductDAO {

	public boolean save(Product product) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean update(Product product) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean delete(Product product) {
		// TODO Auto-generated method stub
		return false;
	}

	public Product get(String pro_id) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Product> list() {
		// TODO Auto-generated method stub
		return null;
	}

}
